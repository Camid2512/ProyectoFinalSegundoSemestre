package co.edu.unbosque.view;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class VentanaNoAdmitido extends JFrame {
	
	private JButton crear, eliminar, actualizar, mostrar, atras;
	private JLabel texto1;
	
	public VentanaNoAdmitido() {
		
		setTitle("NO ADMITIDO");
		setBounds(0, 0, 600, 500);
		setLayout(null);
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		
		
		crear = new JButton("CREAR");
		crear.setBounds(150, 50, 100, 70);
		crear.setForeground(Color.black);
		add(crear);
		
		eliminar = new JButton("ELIMINAR");
		eliminar.setBounds(150, 130, 100, 70);
		eliminar.setForeground(Color.black);
		add(eliminar);
		
		actualizar = new JButton("ACTUALIZAR");
		actualizar.setBounds(150, 210, 100, 70);
		actualizar.setForeground(Color.black);
		add(actualizar);
		
		mostrar = new JButton("MOSTRAR");
		mostrar.setBounds(150, 290, 100, 70);
		mostrar.setForeground(Color.black);
		add(mostrar);
		
		atras = new JButton("ATRAS");
		atras.setBounds(150, 370, 100, 70);
		atras.setForeground(Color.black);
		add(atras);
		
		texto1 = new JLabel();
		texto1.setText("eliga la opcion que decea hacer: ");
		texto1.setBounds(150, 15, 250, 15);
		add(texto1);
		
		// TODO Auto-generated constructor stub
	}

	public JButton getCrear() {
		return crear;
	}

	public void setCrear(JButton crear) {
		this.crear = crear;
	}

	public JButton getEliminar() {
		return eliminar;
	}

	public void setEliminar(JButton eliminar) {
		this.eliminar = eliminar;
	}

	public JButton getActualizar() {
		return actualizar;
	}

	public void setActualizar(JButton actualizar) {
		this.actualizar = actualizar;
	}

	public JButton getMostrar() {
		return mostrar;
	}

	public void setMostrar(JButton mostrar) {
		this.mostrar = mostrar;
	}

	public JButton getAtras() {
		return atras;
	}

	public void setAtras(JButton atras) {
		this.atras = atras;
	}

	public JLabel getTexto1() {
		return texto1;
	}

	public void setTexto1(JLabel texto1) {
		this.texto1 = texto1;
	}
	
	
	
	

}
