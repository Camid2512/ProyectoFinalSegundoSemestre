package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class VentanaPrincipal extends JFrame{
	
	private JButton btn1, btn2;
	private JLabel titulo, imagen;
	
	public VentanaPrincipal() {
		
		setTitle("MENU PRINCIPAL");
		setBounds(0, 0, 600, 500);
		setLayout(null);
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		
		
		
		
		btn1 = new JButton("ADMITIDO");
		btn1.setForeground(Color.black);
		btn1.setBounds(150, 170, 150, 70);
		add(btn1);
		
		btn2 = new JButton("NO ADMITIDO");
		btn2.setForeground(Color.black);
		btn2.setBounds(300, 170, 150, 70);
		add(btn2);
		
		
		titulo = new JLabel();
		titulo.setText("Selecciones si la persona fue admitido o no");
		titulo.setFont(new Font("BigNoodleTitling", Font.PLAIN, 15));
		titulo.setForeground(Color.gray);
		titulo.setBounds(140, 50, 400, 70);
		add(titulo);
		
		imagen = new JLabel();
		imagen.setBounds(0, 0, 600, 500);
		Image temp;
		temp = new ImageIcon("src/co/edu/unbosque/view/imagenes/mi.png").getImage();
		ImageIcon img;
		img = new ImageIcon(temp.getScaledInstance(imagen.getWidth(), imagen.getHeight(), Image.SCALE_SMOOTH));
		imagen.setIcon(img);
		add(imagen);
		
		setVisible(true);
		
		// TODO Auto-generated constructor stub
	}

	public JButton getBtn1() {
		return btn1;
	}

	public void setBtn1(JButton btn1) {
		this.btn1 = btn1;
	}

	public JButton getBtn2() {
		return btn2;
	}

	public void setBtn2(JButton btn2) {
		this.btn2 = btn2;
	}

	public JLabel getTitulo() {
		return titulo;
	}

	public void setTitulo(JLabel titulo) {
		this.titulo = titulo;
	}
	
	

}
