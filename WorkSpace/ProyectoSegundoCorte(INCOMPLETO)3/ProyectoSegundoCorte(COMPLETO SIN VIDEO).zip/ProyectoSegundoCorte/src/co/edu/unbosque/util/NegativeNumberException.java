package co.edu.unbosque.util;

public class NegativeNumberException extends Exception {

	private static final long serialVersionUID = -8725332570790906245L;

	public NegativeNumberException() {

		super("No se puede ingresar un numero negativo");

	}

	public NegativeNumberException(String mensaje) {

		super(mensaje);

	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
