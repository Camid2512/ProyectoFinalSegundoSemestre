package co.edu.unbosque.controller;

public class AplMain {
	
	public static void main(String[] args) {
		Controller c = new Controller();
		c.run();
	}

}
