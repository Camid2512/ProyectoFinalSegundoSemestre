package co.edu.unbosque.util;

public class NumberNotValidException extends Exception {

	/**
	 * ESTA FUNCION SUMA LOS RESULTADOS DE LAS OPERACIONES
	 * 
	 * @author camid
	 */
	private static final long serialVersionUID = -7730475532035294989L;

	public NumberNotValidException() {

		super("El numero no tiene un formato valido");
		// TODO Auto-generated constructor stub
	}

	public NumberNotValidException(String message) {
		super(message);
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
