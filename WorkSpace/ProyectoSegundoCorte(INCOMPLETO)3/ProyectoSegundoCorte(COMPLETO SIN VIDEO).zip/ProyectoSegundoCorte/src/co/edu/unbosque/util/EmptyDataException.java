package co.edu.unbosque.util;

public class EmptyDataException extends Exception {

	private static final long serialVersionUID = -457852048289649104L;

	public EmptyDataException() {

		super("Los datos no estan completos");

	}

	public EmptyDataException(String mensaje) {

		super(mensaje);

	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
