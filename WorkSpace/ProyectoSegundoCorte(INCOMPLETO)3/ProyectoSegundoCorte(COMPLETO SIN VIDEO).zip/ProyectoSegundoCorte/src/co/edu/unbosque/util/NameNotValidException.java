package co.edu.unbosque.util;

public class NameNotValidException extends Exception {

	private static final long serialVersionUID = -2341252176127444523L;

	public NameNotValidException() {
		super("Los nombres no son validos");
	}

	public NameNotValidException(String mensaje) {
		super(mensaje);
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
