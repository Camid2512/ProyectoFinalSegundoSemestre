package co.edu.unbosque.controller;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

import co.edu.unbosque.model.persistence.CivilDAO;
import co.edu.unbosque.model.persistence.ForeignMilitaryDAO;
import co.edu.unbosque.model.persistence.LocalMilitaryDAO;
import co.edu.unbosque.model.persistence.PersonDAO;
import co.edu.unbosque.util.EmptyDataException;
import co.edu.unbosque.util.NameNotValidException;
import co.edu.unbosque.util.NegativeNumberException;
import co.edu.unbosque.util.NumberNotValidException;
import co.edu.unbosque.view.CivilCreateWindow;
import co.edu.unbosque.view.CivilUpdateWindow;
import co.edu.unbosque.view.CivilWindowCRUD;
import co.edu.unbosque.view.MainMilitarWindow;
import co.edu.unbosque.view.MainWindow;
import co.edu.unbosque.view.MilitarForeignCreateWindow;
import co.edu.unbosque.view.MilitarForeignWindowCRUD;
import co.edu.unbosque.view.MilitarLocalCreateWindow;
import co.edu.unbosque.view.MilitarLocalWindowCRUD;
import co.edu.unbosque.view.MilitarlocalUpdateWindow;

public class Controller implements ActionListener {

	private MainWindow mw;

	private CivilWindowCRUD civilWindow;
	private CivilCreateWindow civilCreateWindow;
	private CivilUpdateWindow civilUpdateWindow;

	private MainMilitarWindow mainMilitarWindow;

	private MilitarLocalWindowCRUD militarLocalWindow;
	private MilitarLocalCreateWindow militarLocalCreateWindow;
	private MilitarlocalUpdateWindow militarLocalUpdateWindow;

	private MilitarForeignWindowCRUD militarForeignWindow;
	private MilitarForeignCreateWindow militarForeignCreateWindow;

	private JFileChooser fileChooser;

	private CivilDAO civilDAO;
	private LocalMilitaryDAO militarLocalDAO;
	private ForeignMilitaryDAO militarForeignDAO;
	private PersonDAO personDAO;

	private String photoLocation1;

	public Controller() {

		civilDAO = new CivilDAO();
		militarLocalDAO = new LocalMilitaryDAO();
		militarForeignDAO = new ForeignMilitaryDAO();
		personDAO = new PersonDAO();

		photoLocation1 = "";

		mw = new MainWindow();

		civilWindow = new CivilWindowCRUD();
		civilCreateWindow = new CivilCreateWindow();
		civilUpdateWindow = new CivilUpdateWindow();

		mainMilitarWindow = new MainMilitarWindow();

		militarLocalWindow = new MilitarLocalWindowCRUD();
		militarLocalCreateWindow = new MilitarLocalCreateWindow();
		militarLocalUpdateWindow = new MilitarlocalUpdateWindow();

		militarForeignWindow = new MilitarForeignWindowCRUD();
		militarForeignCreateWindow = new MilitarForeignCreateWindow();

		fileChooser = new JFileChooser();
		agregarLectores();
	}

	public void run() {

		mw.setVisible(true);

	}

	public void agregarLectores() {

		// BOTONES VENTANA PRINCIPAL
		mw.getCivilBtn().addActionListener(this);
		mw.getCivilBtn().setActionCommand("botonCivilPaginaPrincipal");
		mw.getMilitarBtn().addActionListener(this);
		mw.getMilitarBtn().setActionCommand("botonMilitarPaginaPrincipal");
		mw.getVideoBtn().addActionListener(this);
		mw.getVideoBtn().setActionCommand("botonVideoTutorialPaginaPrincipal");
		mw.getSalir().addActionListener(this);
		mw.getSalir().setActionCommand("botonSalirVentanaPrincipal");

		// BOTONES VENTANA CIVIL
		civilWindow.getBackBtn().addActionListener(this);
		civilWindow.getBackBtn().setActionCommand("botonVolverCivil");
		civilWindow.getCreateBtn().addActionListener(this);
		civilWindow.getCreateBtn().setActionCommand("botonCrearCivil");
		civilWindow.getUpdateBtn().addActionListener(this);
		civilWindow.getUpdateBtn().setActionCommand("botonActualizarCivil");

		// BOTONES VENTANA CIVIL CREAR
		civilCreateWindow.getBackBtn().addActionListener(this);
		civilCreateWindow.getBackBtn().setActionCommand("botonVolverCivilCrear");
		civilCreateWindow.getCreateBtn().addActionListener(this);
		civilCreateWindow.getCreateBtn().setActionCommand("botonCivilCrear");
		civilCreateWindow.getFileChooserBtn().addActionListener(this);
		civilCreateWindow.getFileChooserBtn().setActionCommand("escogerArchivoBotonCivil");

		// BOTONES VENTANA CIVIL ACTUALIZAR
		civilUpdateWindow.getBackBtn().addActionListener(this);
		civilUpdateWindow.getBackBtn().setActionCommand("botonVolverCivilActualizar");
		civilUpdateWindow.getUpdateBtn().addActionListener(this);
		civilUpdateWindow.getUpdateBtn().setActionCommand("botonCivilActualizar");
		civilUpdateWindow.getFileChooserBtn().addActionListener(this);
		civilUpdateWindow.getFileChooserBtn().setActionCommand("escogerArchivoBotonActualizar");

		// BOTONES VENTANA MILITAR
		mainMilitarWindow.getBackBtn().addActionListener(this);
		mainMilitarWindow.getBackBtn().setActionCommand("botonVolverMilitarMain");
		mainMilitarWindow.getMilitarLocal().addActionListener(this);
		mainMilitarWindow.getMilitarLocal().setActionCommand("botonMilitarLocal");
		mainMilitarWindow.getMilitarForeign().addActionListener(this);
		mainMilitarWindow.getMilitarForeign().setActionCommand("botonMilitarExtranjero");

		// BOTONES VENTANA MILITAR LOCAL
		militarLocalWindow.getBackBtn().addActionListener(this);
		militarLocalWindow.getBackBtn().setActionCommand("botonVolverMilitarLocal");
		militarLocalWindow.getCreateBtn().addActionListener(this);
		militarLocalWindow.getCreateBtn().setActionCommand("botonCrearMilitarLocal");
		militarLocalWindow.getUpdateBtn().addActionListener(this);
		militarLocalWindow.getUpdateBtn().setActionCommand("botonActualizarMilitarLocal");

		// BOTONES VENTANA MILITAR LOCAL CREAR
		militarLocalCreateWindow.getBackBtn().addActionListener(this);
		militarLocalCreateWindow.getBackBtn().setActionCommand("botonVolverMilitarLocalCrear");
		militarLocalCreateWindow.getCreateBtn().addActionListener(this);
		militarLocalCreateWindow.getCreateBtn().setActionCommand("botonCrearMilitarLocalCrear");
		militarLocalCreateWindow.getFileChooserBtn().addActionListener(this);
		militarLocalCreateWindow.getFileChooserBtn().setActionCommand("escogerArchivoBotonMilitarLocal");

		// BOTONES VENTANA MILITAR LOCAL ACTUALIZAR
		militarLocalUpdateWindow.getBackBtn().addActionListener(this);
		militarLocalUpdateWindow.getBackBtn().setActionCommand("botonVolverMilitarLocalActualizar");
		militarLocalUpdateWindow.getUpdateBtn().addActionListener(this);
		militarLocalUpdateWindow.getUpdateBtn().setActionCommand("botonActualizarMilitarLocalActualizar");
		militarLocalUpdateWindow.getFileChooserBtn().addActionListener(this);
		militarLocalUpdateWindow.getFileChooserBtn().setActionCommand("escogerArchivoBotonMilitarLocalActualizar");

		// BOTONES VENTANA MILITAR EXTRANJERO
		militarForeignWindow.getBackBtn().addActionListener(this);
		militarForeignWindow.getBackBtn().setActionCommand("botonVolverMilitarExtranjero");
		militarForeignWindow.getCreateBtn().addActionListener(this);
		militarForeignWindow.getCreateBtn().setActionCommand("botonCrearMilitarExtranjero");

		// BOTONES VENTANA MILITAR EXTRANKERO CREAR
		militarForeignCreateWindow.getBackBtn().addActionListener(this);
		militarForeignCreateWindow.getBackBtn().setActionCommand("botonVolverMilitarExtranjeroCrear");
		militarForeignCreateWindow.getCreateBtn().addActionListener(this);
		militarForeignCreateWindow.getCreateBtn().setActionCommand("botonCrearMilitarExtranjeroCrear");
		militarForeignCreateWindow.getFileChooserBtn().addActionListener(this);
		militarForeignCreateWindow.getFileChooserBtn().setActionCommand("escogerArchivoBotonMilitarExtranjero");

	}

	public void actionPerformed(ActionEvent e) {
		switch (e.getActionCommand()) {

		// CASOS BOTONES VENTANA PRINCIPAL
		case "botonCivilPaginaPrincipal": {
			mw.setVisible(false);
			civilWindow.setVisible(true);

			break;
		}

		case "botonMilitarPaginaPrincipal": {
			mw.setVisible(false);
			mainMilitarWindow.setVisible(true);

			break;
		}

		case "botonVideoTutorialPaginaPrincipal": {
			JOptionPane.showConfirmDialog(mw, "PRUEBA", "PRUEBITA", JOptionPane.YES_NO_OPTION,
					JOptionPane.QUESTION_MESSAGE);
			break;
		}

		case "botonSalirVentanaPrincipal": {
			System.exit(1);
			break;
		}

		// CASOS BOTONES CIVIL
		case "botonVolverCivil": {
			mw.setVisible(true);
			civilWindow.setVisible(false);

			break;
		}
		case "botonCrearCivil": {

			mw.setVisible(false);
			civilWindow.setVisible(false);
			civilCreateWindow.setVisible(true);
			break;
		}
		case "botonActualizarCivil": {
			mw.setVisible(false);
			civilWindow.setVisible(false);
			civilUpdateWindow.setVisible(true);
			break;
		}
		case "escogerArchivoBotonCivil": {

			FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & PNG", "jpeg", "JPEG", "jpg", "JPG",
					"png", "PNG");
			fileChooser.setFileFilter(filter);

			int response = fileChooser.showOpenDialog(null);
			if (response == JFileChooser.APPROVE_OPTION) {

				String photoLocation = fileChooser.getSelectedFile().getPath();
				createCopyOfImage(photoLocation);
				photoLocation1 = createCopyOfImage(photoLocation);

				Image myImage = new ImageIcon(photoLocation).getImage();
				ImageIcon myIcon = new ImageIcon(myImage.getScaledInstance(372, 385, Image.SCALE_DEFAULT));

				civilCreateWindow.getPersonalPhoto().setIcon(myIcon);
				;

			}

			break;
		}
		// CASOS BOTONES CREAR CIVIL

		case "botonVolverCivilCrear": {

			civilCreateWindow.setVisible(false);
			civilCreateWindow.getDocTxt().setText("");
			civilCreateWindow.getNameTxt().setText("");
			civilCreateWindow.getDayBirthTxt().setText("");
			civilCreateWindow.getMonthBirthTxt().setText("");
			civilCreateWindow.getYearBirthTxt().setText("");
			civilCreateWindow.getStudiesTxt().setText("");
			civilCreateWindow.getTimeArmyTxt().setText("");
			civilCreateWindow.getPersonalPhoto().setIcon(null);
			civilWindow.setVisible(true);

			break;
		}
		case "botonCivilCrear": {
			while (true) {

				try {
					createCivil();
					JOptionPane.showMessageDialog(civilCreateWindow, "Se ha creado con exito la persona civil");
					String message = civilDAO.readAll();
					JOptionPane.showMessageDialog(civilCreateWindow, message);
				} catch (NumberFormatException ex) {
					JOptionPane.showMessageDialog(mw, "DATOS INCORRECTOS", "ERROR", 0);
				}
				civilCreateWindow.getDocTxt().setText("");
				civilCreateWindow.getNameTxt().setText("");
				civilCreateWindow.getDayBirthTxt().setText("");
				civilCreateWindow.getMonthBirthTxt().setText("");
				civilCreateWindow.getYearBirthTxt().setText("");
				civilCreateWindow.getStudiesTxt().setText("");
				civilCreateWindow.getTimeArmyTxt().setText("");
				civilCreateWindow.getPersonalPhoto().setIcon(null);
				break;
			}
			break;
		}

		case "escogerArchivoBotonActualizar": {

			FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & PNG", "jpeg", "JPEG", "jpg", "JPG",
					"png", "PNG");
			fileChooser.setFileFilter(filter);

			int response = fileChooser.showOpenDialog(null);
			if (response == JFileChooser.APPROVE_OPTION) {

				String photoLocation = fileChooser.getSelectedFile().getPath();
				createCopyOfImage(photoLocation);
				photoLocation1 = createCopyOfImage(photoLocation);

				Image myImage = new ImageIcon(photoLocation).getImage();
				ImageIcon myIcon = new ImageIcon(myImage.getScaledInstance(372, 385, Image.SCALE_DEFAULT));

				civilUpdateWindow.getPersonalPhoto().setIcon(myIcon);
				;

			}

			break;
		}
		// CASOS BOTONES ACTUALIZAR CIVIL
		case "botonVolverCivilActualizar": {

			civilUpdateWindow.setVisible(false);
			civilUpdateWindow.getDocTxt().setText("");
			civilUpdateWindow.getNameTxt().setText("");
			civilUpdateWindow.getDayBirthTxt().setText("");
			civilUpdateWindow.getMonthBirthTxt().setText("");
			civilUpdateWindow.getYearBirthTxt().setText("");
			civilUpdateWindow.getStudiesTxt().setText("");
			civilUpdateWindow.getTimeArmyTxt().setText("");
			civilUpdateWindow.getIndexTxt().setText("");
			civilUpdateWindow.getPersonalPhoto().setIcon(null);
			civilWindow.setVisible(true);

			break;
		}
		case "botonCivilActualizar": {

			while (true) {

				try {
					updateCivil();
					JOptionPane.showMessageDialog(civilUpdateWindow, "Se ha actualizado con exito la persona civil");
				} catch (NumberFormatException ex) {
				}
				civilUpdateWindow.getDocTxt().setText("");
				civilUpdateWindow.getNameTxt().setText("");
				civilUpdateWindow.getDayBirthTxt().setText("");
				civilUpdateWindow.getMonthBirthTxt().setText("");
				civilUpdateWindow.getYearBirthTxt().setText("");
				civilUpdateWindow.getStudiesTxt().setText("");
				civilUpdateWindow.getTimeArmyTxt().setText("");
				civilUpdateWindow.getIndexTxt().setText("");
				civilUpdateWindow.getPersonalPhoto().setIcon(null);
				break;
			}
			break;
		}
		// CASOS BOTONES MILITAR
		case "botonVolverMilitarMain": {
			mw.setVisible(true);
			mainMilitarWindow.setVisible(false);

			break;
		}
		case "botonMilitarExtranjero": {
			mw.setVisible(false);
			mainMilitarWindow.setVisible(false);
			militarForeignWindow.setVisible(true);

			break;
		}
		case "botonMilitarLocal": {
			mw.setVisible(false);
			mainMilitarWindow.setVisible(false);
			militarLocalWindow.setVisible(true);

			break;
		}

		// CASOS BOTONES MILITAR LOCAL
		case "botonVolverMilitarLocal": {
			militarLocalWindow.setVisible(false);
			mainMilitarWindow.setVisible(true);

			break;
		}
		case "botonCrearMilitarLocal": {

			mw.setVisible(false);
			militarLocalCreateWindow.setVisible(true);
			militarLocalWindow.setVisible(false);
			break;
		}
		case "botonActualizarMilitarLocal": {

			mw.setVisible(false);
			militarLocalUpdateWindow.setVisible(true);
			militarLocalWindow.setVisible(false);
			break;
		}
		case "escogerArchivoBotonMilitarLocal": {

			FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & PNG", "jpeg", "JPEG", "jpg", "JPG",
					"png", "PNG");
			fileChooser.setFileFilter(filter);

			int response = fileChooser.showOpenDialog(null);
			if (response == JFileChooser.APPROVE_OPTION) {

				String photoLocation = fileChooser.getSelectedFile().getPath();
				createCopyOfImage(photoLocation);
				photoLocation1 = createCopyOfImage(photoLocation);

				Image myImage = new ImageIcon(photoLocation).getImage();
				ImageIcon myIcon = new ImageIcon(myImage.getScaledInstance(372, 385, Image.SCALE_DEFAULT));

				militarLocalCreateWindow.getPersonalPhoto().setIcon(myIcon);
				;

			}

			break;
		}
		// CASOS BOTONES CREAR MILITAR LOCAL;

		case "botonVolverMilitarLocalCrear": {

			militarLocalCreateWindow.setVisible(false);
			militarLocalCreateWindow.getDocTxt().setText("");
			militarLocalCreateWindow.getNameTxt().setText("");
			militarLocalCreateWindow.getDayBirthTxt().setText("");
			militarLocalCreateWindow.getMonthBirthTxt().setText("");
			militarLocalCreateWindow.getYearBirthTxt().setText("");
			militarLocalCreateWindow.getRankTxt().setText("");
			militarLocalCreateWindow.getServiceTimeTxt().setText("");
			militarLocalCreateWindow.getPersonalPhoto().setIcon(null);
			militarLocalWindow.setVisible(true);

			break;
		}
		case "botonCrearMilitarLocalCrear": {
			while (true) {

				try {
					createMilitarLocal();
					JOptionPane.showMessageDialog(militarLocalCreateWindow, "Se ha creado con exito el Militar Local");
				} catch (NumberFormatException ex) {
					JOptionPane.showMessageDialog(mw, "DATOS INCORRECTOS", "ERROR", 0);
				}
				militarLocalCreateWindow.getDocTxt().setText("");
				militarLocalCreateWindow.getNameTxt().setText("");
				militarLocalCreateWindow.getDayBirthTxt().setText("");
				militarLocalCreateWindow.getMonthBirthTxt().setText("");
				militarLocalCreateWindow.getYearBirthTxt().setText("");
				militarLocalCreateWindow.getRankTxt().setText("");
				militarLocalCreateWindow.getServiceTimeTxt().setText("");
				militarLocalCreateWindow.getPersonalPhoto().setIcon(null);
				break;
			}
			break;
		}
		case "escogerArchivoBotonMilitarLocalActualizar": {

			FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & PNG", "jpeg", "JPEG", "jpg", "JPG",
					"png", "PNG");
			fileChooser.setFileFilter(filter);

			int response = fileChooser.showOpenDialog(null);
			if (response == JFileChooser.APPROVE_OPTION) {

				String photoLocation = fileChooser.getSelectedFile().getPath();
				createCopyOfImage(photoLocation);
				photoLocation1 = createCopyOfImage(photoLocation);

				Image myImage = new ImageIcon(photoLocation).getImage();
				ImageIcon myIcon = new ImageIcon(myImage.getScaledInstance(372, 385, Image.SCALE_DEFAULT));

				militarLocalUpdateWindow.getPersonalPhoto().setIcon(myIcon);
				;

			}

			break;
		}
		// CASOS BOTONES ACTUALIZAR CIVIL

		case "botonVolverMilitarLocalActualizar": {

			militarLocalUpdateWindow.setVisible(false);
			militarLocalUpdateWindow.getDocTxt().setText("");
			militarLocalUpdateWindow.getNameTxt().setText("");
			militarLocalUpdateWindow.getDayBirthTxt().setText("");
			militarLocalUpdateWindow.getMonthBirthTxt().setText("");
			militarLocalUpdateWindow.getYearBirthTxt().setText("");
			militarLocalUpdateWindow.getRankTxt().setText("");
			militarLocalUpdateWindow.getServiceTimeTxt().setText("");
			militarLocalUpdateWindow.getPersonalPhoto().setIcon(null);
			militarLocalWindow.setVisible(true);

			break;
		}
		case "botonActualizarMilitarLocalActualizar": {
			while (true) {

				try {
					updateMilitarLocal();
					JOptionPane.showMessageDialog(militarLocalUpdateWindow,
							"Se ha actualizado con exito el militar local");
				} catch (NumberFormatException ex) {
				}
				militarLocalUpdateWindow.getDocTxt().setText("");
				militarLocalUpdateWindow.getNameTxt().setText("");
				militarLocalUpdateWindow.getDayBirthTxt().setText("");
				militarLocalUpdateWindow.getMonthBirthTxt().setText("");
				militarLocalUpdateWindow.getYearBirthTxt().setText("");
				militarLocalUpdateWindow.getRankTxt().setText("");
				militarLocalUpdateWindow.getServiceTimeTxt().setText("");
				militarLocalUpdateWindow.getIndexTxt().setText("");
				militarLocalUpdateWindow.getPersonalPhoto().setIcon(null);
				break;
			}
			break;

		}
		// CASOS BOTONES MILITAR EXTRANJERO
		case "botonVolverMilitarExtranjero": {
			militarForeignWindow.setVisible(false);
			mainMilitarWindow.setVisible(true);

			break;
		}
		case "botonCrearMilitarExtranjero": {
			mw.setVisible(false);
			militarForeignCreateWindow.setVisible(true);
			militarForeignWindow.setVisible(false);
			break;
		}
		case "escogerArchivoBotonMilitarExtranjero": {

			FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & PNG", "jpeg", "JPEG", "jpg", "JPG",
					"png", "PNG");
			fileChooser.setFileFilter(filter);

			int response = fileChooser.showOpenDialog(null);
			if (response == JFileChooser.APPROVE_OPTION) {

				String photoLocation = fileChooser.getSelectedFile().getPath();
				createCopyOfImage(photoLocation);
				photoLocation1 = createCopyOfImage(photoLocation);

				Image myImage = new ImageIcon(photoLocation).getImage();
				ImageIcon myIcon = new ImageIcon(myImage.getScaledInstance(372, 385, Image.SCALE_DEFAULT));

				militarForeignCreateWindow.getPersonalPhoto().setIcon(myIcon);

			}

			break;
		}
		// CASOS BOTONES CREAR CIVIL

		case "botonVolverMilitarExtranjeroCrear": {

			militarForeignCreateWindow.setVisible(false);
			militarForeignCreateWindow.getDocTxt().setText("");
			militarForeignCreateWindow.getNameTxt().setText("");
			militarForeignCreateWindow.getDayBirthTxt().setText("");
			militarForeignCreateWindow.getMonthBirthTxt().setText("");
			militarForeignCreateWindow.getYearBirthTxt().setText("");
			militarForeignCreateWindow.getCountryOfOriginTxt().setText("");
			militarForeignCreateWindow.getTimeInOurCountryTxt().setText("");
			militarForeignCreateWindow.getPersonalPhoto().setIcon(null);
			militarForeignWindow.setVisible(true);

			break;
		}
		case "botonCrearMilitarExtranjeroCrear": {
			while (true) {

				try {
					createMilitarForeign();
					JOptionPane.showMessageDialog(militarForeignCreateWindow,
							"Se ha creado con exito el Militar Extranjero");
				} catch (NumberFormatException ex) {
					JOptionPane.showMessageDialog(mw, "DATOS INCORRECTOS", "ERROR", 0);
				}
				militarForeignCreateWindow.getDocTxt().setText("");
				militarForeignCreateWindow.getNameTxt().setText("");
				militarForeignCreateWindow.getDayBirthTxt().setText("");
				militarForeignCreateWindow.getMonthBirthTxt().setText("");
				militarForeignCreateWindow.getYearBirthTxt().setText("");
				militarForeignCreateWindow.getCountryOfOriginTxt().setText("");
				militarForeignCreateWindow.getTimeInOurCountryTxt().setText("");
				militarForeignCreateWindow.getPersonalPhoto().setIcon(null);
				break;
			}
			break;
		}

		default: {

			break;

		}
		}

	}

	public void createCivil() {
		String document = "";
		String name = "";
		String dayOfBirth = "";
		String monthOfBirth = "";
		String yearOfBirth = "";
		String photoLocation = "";
		String age = "";
		String studiesLevel = "";
		String timeWorkingInArmy = "";

		int day = 0;
		int month = 0;
		int year = 0;
		while (true) {
			try {
				checkIsNotANumber(document);
				document = civilCreateWindow.getDocTxt().getText();
				checkIsNotANumber(document);
				checkNegativeLongNumber(document);

				name = civilCreateWindow.getNameTxt().getText();
				checkName(name);

				checkIsNotANumber(dayOfBirth);
				dayOfBirth = civilCreateWindow.getDayBirthTxt().getText();
				checkIsNotANumber(dayOfBirth);
				checkDay(dayOfBirth);
				checkNegativeIntegerNumber(dayOfBirth);

				checkIsNotANumber(monthOfBirth);
				monthOfBirth = civilCreateWindow.getMonthBirthTxt().getText();
				checkIsNotANumber(monthOfBirth);
				checkMonth(monthOfBirth);
				checkNegativeIntegerNumber(monthOfBirth);

				checkIsNotANumber(yearOfBirth);
				yearOfBirth = civilCreateWindow.getYearBirthTxt().getText();
				checkIsNotANumber(yearOfBirth);
				checkYear(yearOfBirth);
				checkNegativeIntegerNumber(yearOfBirth);

				studiesLevel = civilCreateWindow.getStudiesTxt().getText();
				checkName(studiesLevel);

				photoLocation = photoLocation1;

				checkIsNotANumber(timeWorkingInArmy);
				timeWorkingInArmy = civilCreateWindow.getTimeArmyTxt().getText();
				checkIsNotANumber(timeWorkingInArmy);
				checkNegativeIntegerNumber(timeWorkingInArmy);
			} catch (NumberNotValidException e) {

			} catch (NegativeNumberException e) {
				// TODO Auto-generated catch block
			} catch (NameNotValidException e) {
				// TODO Auto-generated catch block
			}

			day = Integer.parseInt(dayOfBirth);
			month = Integer.parseInt(monthOfBirth);
			year = Integer.parseInt(yearOfBirth);
			age = String.valueOf(personDAO.ageCalculation(day, month, year));
			break;
		}

		civilDAO.create(document, name, dayOfBirth, monthOfBirth, yearOfBirth, age, photoLocation, studiesLevel,
				timeWorkingInArmy);
		try {
			checkIsEmpty(document, name, dayOfBirth, monthOfBirth, yearOfBirth, studiesLevel, photoLocation,
					timeWorkingInArmy);
		} catch (EmptyDataException e) {
			// TODO Auto-generated catch block
		}

	}

	public void updateCivil() {
		int index = 0;
		String document = "";
		String name = "";
		String dayOfBirth = "";
		String monthOfBirth = "";
		String yearOfBirth = "";
		String photoLocation = "";
		String age = "";
		String studiesLevel = "";
		String timeWorkingInArmy = "";

		int day = 0;
		int month = 0;
		int year = 0;

		index = Integer.parseInt(civilUpdateWindow.getIndexTxt().getText());

		document = civilUpdateWindow.getDocTxt().getText();

		name = civilUpdateWindow.getNameTxt().getText();

		dayOfBirth = civilUpdateWindow.getDayBirthTxt().getText();

		monthOfBirth = civilUpdateWindow.getMonthBirthTxt().getText();

		yearOfBirth = civilUpdateWindow.getYearBirthTxt().getText();

		studiesLevel = civilUpdateWindow.getStudiesTxt().getText();

		timeWorkingInArmy = civilUpdateWindow.getTimeArmyTxt().getText();

		day = Integer.parseInt(dayOfBirth);
		month = Integer.parseInt(monthOfBirth);
		year = Integer.parseInt(yearOfBirth);
		age = String.valueOf(personDAO.ageCalculation(day, month, year));
		civilDAO.updateByIndex(index, document, name, dayOfBirth, monthOfBirth, yearOfBirth, age, photoLocation,
				studiesLevel, timeWorkingInArmy);

	}

	public void createMilitarLocal() {
		String document = "";
		String name = "";
		String dayOfBirth = "";
		String monthOfBirth = "";
		String yearOfBirth = "";
		String photoLocation = "";
		String age = "";
		String rank = "";
		String serviceTime = "";

		int day = 0;
		int month = 0;
		int year = 0;
		while (true) {
			try {
				checkIsNotANumber(document);
				document = militarLocalCreateWindow.getDocTxt().getText();
				checkIsNotANumber(document);
				checkNegativeLongNumber(document);

				name = militarLocalCreateWindow.getNameTxt().getText();
				checkName(name);

				checkIsNotANumber(dayOfBirth);
				dayOfBirth = militarLocalCreateWindow.getDayBirthTxt().getText();
				checkIsNotANumber(dayOfBirth);
				checkDay(dayOfBirth);
				checkNegativeIntegerNumber(dayOfBirth);

				checkIsNotANumber(monthOfBirth);
				monthOfBirth = militarLocalCreateWindow.getMonthBirthTxt().getText();
				checkIsNotANumber(monthOfBirth);
				checkMonth(monthOfBirth);
				checkNegativeIntegerNumber(monthOfBirth);

				checkIsNotANumber(yearOfBirth);
				yearOfBirth = militarLocalCreateWindow.getYearBirthTxt().getText();
				checkIsNotANumber(yearOfBirth);
				checkYear(yearOfBirth);
				checkNegativeIntegerNumber(yearOfBirth);

				rank = militarLocalCreateWindow.getRankTxt().getText();
				checkName(rank);

				photoLocation = photoLocation1;

				checkIsNotANumber(serviceTime);
				serviceTime = militarLocalCreateWindow.getServiceTimeTxt().getText();
				checkIsNotANumber(serviceTime);
				checkNegativeIntegerNumber(serviceTime);
			} catch (NumberNotValidException e) {
				militarLocalCreateWindow.getDocTxt().setText("");
				militarLocalCreateWindow.getNameTxt().setText("");
				militarLocalCreateWindow.getDayBirthTxt().setText("");
				militarLocalCreateWindow.getMonthBirthTxt().setText("");
				militarLocalCreateWindow.getYearBirthTxt().setText("");
				militarLocalCreateWindow.getRankTxt().setText("");
				militarLocalCreateWindow.getServiceTimeTxt().setText("");
				militarLocalCreateWindow.getPersonalPhoto().setIcon(null);
			} catch (NegativeNumberException e) {
				militarLocalCreateWindow.getDocTxt().setText("");
				militarLocalCreateWindow.getNameTxt().setText("");
				militarLocalCreateWindow.getDayBirthTxt().setText("");
				militarLocalCreateWindow.getMonthBirthTxt().setText("");
				militarLocalCreateWindow.getYearBirthTxt().setText("");
				militarLocalCreateWindow.getRankTxt().setText("");
				militarLocalCreateWindow.getServiceTimeTxt().setText("");
				militarLocalCreateWindow.getPersonalPhoto().setIcon(null);
			} catch (NameNotValidException e) {
				militarLocalCreateWindow.getDocTxt().setText("");
				militarLocalCreateWindow.getNameTxt().setText("");
				militarLocalCreateWindow.getDayBirthTxt().setText("");
				militarLocalCreateWindow.getMonthBirthTxt().setText("");
				militarLocalCreateWindow.getYearBirthTxt().setText("");
				militarLocalCreateWindow.getRankTxt().setText("");
				militarLocalCreateWindow.getServiceTimeTxt().setText("");
				militarLocalCreateWindow.getPersonalPhoto().setIcon(null);
			}

			day = Integer.parseInt(dayOfBirth);
			month = Integer.parseInt(monthOfBirth);
			year = Integer.parseInt(yearOfBirth);
			age = String.valueOf(personDAO.ageCalculation(day, month, year));
			break;
		}

		militarLocalDAO.create(document, name, dayOfBirth, monthOfBirth, yearOfBirth, age, photoLocation, rank,
				serviceTime);
		try {
			checkIsEmpty(document, name, dayOfBirth, monthOfBirth, yearOfBirth, rank, photoLocation, serviceTime);
		} catch (EmptyDataException e) {
			// TODO Auto-generated catch block
		}
	}

	public void updateMilitarLocal() {
		int index = 0;
		String document = "";
		String name = "";
		String dayOfBirth = "";
		String monthOfBirth = "";
		String yearOfBirth = "";
		String photoLocation = "";
		String age = "";
		String rank = "";
		String serviceTime = "";

		int day = 0;
		int month = 0;
		int year = 0;

		index = Integer.parseInt(militarLocalUpdateWindow.getIndexTxt().getText());

		document = militarLocalUpdateWindow.getDocTxt().getText();

		name = militarLocalUpdateWindow.getNameTxt().getText();

		dayOfBirth = militarLocalUpdateWindow.getDayBirthTxt().getText();

		monthOfBirth = militarLocalUpdateWindow.getMonthBirthTxt().getText();

		yearOfBirth = militarLocalUpdateWindow.getYearBirthTxt().getText();

		rank = militarLocalUpdateWindow.getRankTxt().getText();

		serviceTime = militarLocalUpdateWindow.getServiceTimeTxt().getText();

		day = Integer.parseInt(dayOfBirth);
		month = Integer.parseInt(monthOfBirth);
		year = Integer.parseInt(yearOfBirth);
		age = String.valueOf(personDAO.ageCalculation(day, month, year));
		militarLocalDAO.updateByIndex(index, document, name, dayOfBirth, monthOfBirth, yearOfBirth, age, photoLocation,
				rank, serviceTime);

	}

	public void createMilitarForeign() {
		String document = "";
		String name = "";
		String dayOfBirth = "";
		String monthOfBirth = "";
		String yearOfBirth = "";
		String photoLocation = "";
		String age = "";
		String countryOfOrigin = "";
		String timeInOurCountry = "";

		int day = 0;
		int month = 0;
		int year = 0;
		while (true) {
			try {
				checkIsNotANumber(document);
				document = militarForeignCreateWindow.getDocTxt().getText();
				checkIsNotANumber(document);
				checkNegativeLongNumber(document);

				name = militarForeignCreateWindow.getNameTxt().getText();
				checkName(name);

				checkIsNotANumber(dayOfBirth);
				dayOfBirth = militarForeignCreateWindow.getDayBirthTxt().getText();
				checkIsNotANumber(dayOfBirth);
				checkDay(dayOfBirth);
				checkNegativeIntegerNumber(dayOfBirth);

				checkIsNotANumber(monthOfBirth);
				monthOfBirth = militarForeignCreateWindow.getMonthBirthTxt().getText();
				checkIsNotANumber(monthOfBirth);
				checkMonth(monthOfBirth);
				checkNegativeIntegerNumber(monthOfBirth);

				checkIsNotANumber(yearOfBirth);
				yearOfBirth = militarForeignCreateWindow.getYearBirthTxt().getText();
				checkIsNotANumber(yearOfBirth);
				checkYear(yearOfBirth);
				checkNegativeIntegerNumber(yearOfBirth);

				countryOfOrigin = militarForeignCreateWindow.getCountryOfOriginTxt().getText();
				checkName(countryOfOrigin);

				photoLocation = photoLocation1;

				checkIsNotANumber(timeInOurCountry);
				timeInOurCountry = militarForeignCreateWindow.getTimeInOurCountryTxt().getText();
				checkIsNotANumber(timeInOurCountry);
				checkNegativeIntegerNumber(timeInOurCountry);
			} catch (NumberNotValidException e) {
				militarForeignCreateWindow.getDocTxt().setText("");
				militarForeignCreateWindow.getNameTxt().setText("");
				militarForeignCreateWindow.getDayBirthTxt().setText("");
				militarForeignCreateWindow.getMonthBirthTxt().setText("");
				militarForeignCreateWindow.getYearBirthTxt().setText("");
				militarForeignCreateWindow.getCountryOfOriginTxt().setText("");
				militarForeignCreateWindow.getTimeInOurCountryTxt().setText("");
				militarForeignCreateWindow.getPersonalPhoto().setIcon(null);
			} catch (NegativeNumberException e) {
				militarForeignCreateWindow.getDocTxt().setText("");
				militarForeignCreateWindow.getNameTxt().setText("");
				militarForeignCreateWindow.getDayBirthTxt().setText("");
				militarForeignCreateWindow.getMonthBirthTxt().setText("");
				militarForeignCreateWindow.getYearBirthTxt().setText("");
				militarForeignCreateWindow.getCountryOfOriginTxt().setText("");
				militarForeignCreateWindow.getTimeInOurCountryTxt().setText("");
				militarForeignCreateWindow.getPersonalPhoto().setIcon(null);
			} catch (NameNotValidException e) {
				militarForeignCreateWindow.getDocTxt().setText("");
				militarForeignCreateWindow.getNameTxt().setText("");
				militarForeignCreateWindow.getDayBirthTxt().setText("");
				militarForeignCreateWindow.getMonthBirthTxt().setText("");
				militarForeignCreateWindow.getYearBirthTxt().setText("");
				militarForeignCreateWindow.getCountryOfOriginTxt().setText("");
				militarForeignCreateWindow.getTimeInOurCountryTxt().setText("");
				militarForeignCreateWindow.getPersonalPhoto().setIcon(null);
			}

			day = Integer.parseInt(dayOfBirth);
			month = Integer.parseInt(monthOfBirth);
			year = Integer.parseInt(yearOfBirth);
			age = String.valueOf(personDAO.ageCalculation(day, month, year));
			break;
		}

		militarForeignDAO.create(document, name, dayOfBirth, monthOfBirth, yearOfBirth, age, photoLocation,
				countryOfOrigin, timeInOurCountry);
		try {
			checkIsEmpty(document, name, dayOfBirth, monthOfBirth, yearOfBirth, countryOfOrigin, photoLocation,
					timeInOurCountry);
		} catch (EmptyDataException e) {
			// TODO Auto-generated catch block
		}
	}

	public void checkIsNotANumber(String num) throws NumberNotValidException {

		String message = "LOS NUMEROS SOLO PUEDEN SER NUMEROS";

		for (char c : num.toCharArray()) {
			if (Character.isAlphabetic(c)) {
				JOptionPane.showMessageDialog(mw, message, "ERROR", 0);
				civilCreateWindow.getDocTxt().setText(null);
				civilCreateWindow.getDayBirthTxt().setText(null);
				civilCreateWindow.getMonthBirthTxt().setText(null);
				civilCreateWindow.getYearBirthTxt().setText(null);
				civilCreateWindow.getTimeArmyTxt().setText(null);
				civilCreateWindow.getNameTxt().setText(null);
				civilCreateWindow.getStudiesTxt().setText(null);
				civilCreateWindow.getPersonalPhoto().setIcon(null);
				throw new NumberNotValidException(message);
			}
		}

	}

	public void checkNegativeIntegerNumber(String num) throws NegativeNumberException {

		String message = "NINGUNO DE LOS NUMEROS PUEDE SER NEGATIVO";
		if (Integer.parseInt(num) < 0) {

			JOptionPane.showMessageDialog(mw, message, "ERROR", 0);
			civilCreateWindow.getDocTxt().setText(null);
			civilCreateWindow.getDayBirthTxt().setText(null);
			civilCreateWindow.getMonthBirthTxt().setText(null);
			civilCreateWindow.getYearBirthTxt().setText(null);
			civilCreateWindow.getTimeArmyTxt().setText(null);
			civilCreateWindow.getNameTxt().setText(null);
			civilCreateWindow.getStudiesTxt().setText(null);
			civilCreateWindow.getPersonalPhoto().setIcon(null);
			throw new NegativeNumberException(message);
		}

	}

	public void checkNegativeLongNumber(String num) throws NegativeNumberException {

		String message = "NINGUNO DE LOS NUMEROS PUEDE SER NEGATIVO";
		if (Long.parseLong(num) < 0) {

			JOptionPane.showMessageDialog(mw, "NINGUNO DE LOS NUMEROS PUEDE SER NEGATIVO", "ERROR", 0);
			civilCreateWindow.getDocTxt().setText(null);
			civilCreateWindow.getDayBirthTxt().setText(null);
			civilCreateWindow.getMonthBirthTxt().setText(null);
			civilCreateWindow.getYearBirthTxt().setText(null);
			civilCreateWindow.getTimeArmyTxt().setText(null);
			civilCreateWindow.getNameTxt().setText(null);
			civilCreateWindow.getStudiesTxt().setText(null);
			civilCreateWindow.getPersonalPhoto().setIcon(null);
			throw new NegativeNumberException(message);
		}

	}

	public void checkName(String name) throws NameNotValidException {

		String message = "LOS NOMBRES NO CONTIENEN CARACTERES ESPECIALES";
		for (char c : name.toCharArray()) {
			if (!Character.isAlphabetic(c) && !Character.isWhitespace(c)) {
				JOptionPane.showMessageDialog(civilCreateWindow, message, "ERROR", 0);
				civilCreateWindow.getDocTxt().setText(null);
				civilCreateWindow.getDayBirthTxt().setText(null);
				civilCreateWindow.getMonthBirthTxt().setText(null);
				civilCreateWindow.getYearBirthTxt().setText(null);
				civilCreateWindow.getTimeArmyTxt().setText(null);
				civilCreateWindow.getNameTxt().setText(null);
				civilCreateWindow.getStudiesTxt().setText(null);
				civilCreateWindow.getPersonalPhoto().setIcon(null);
				throw new NameNotValidException(message);
			}
		}
	}

	public void checkDay(String day) {

		int dayCheck = Integer.parseInt(day);

		if (dayCheck > 30) {
			JOptionPane.showMessageDialog(mw, "LOS DIAS DEL MES NO PUEDEN SER MAYORES A 30", "ERROR", 0);
			civilCreateWindow.getDocTxt().setText(null);
			civilCreateWindow.getDayBirthTxt().setText(null);
			civilCreateWindow.getMonthBirthTxt().setText(null);
			civilCreateWindow.getYearBirthTxt().setText(null);
			civilCreateWindow.getTimeArmyTxt().setText(null);
			civilCreateWindow.getNameTxt().setText(null);
			civilCreateWindow.getStudiesTxt().setText(null);
			civilCreateWindow.getPersonalPhoto().setIcon(null);
		}

	}

	public void checkMonth(String month) {

		int monthCheck = Integer.parseInt(month);

		if (monthCheck > 12) {
			JOptionPane.showMessageDialog(mw, "NO HAY MAS DE 12 MESES EN EL AÑO", "ERROR", 0);
			civilCreateWindow.getDocTxt().setText(null);
			civilCreateWindow.getDayBirthTxt().setText(null);
			civilCreateWindow.getMonthBirthTxt().setText(null);
			civilCreateWindow.getYearBirthTxt().setText(null);
			civilCreateWindow.getTimeArmyTxt().setText(null);
			civilCreateWindow.getNameTxt().setText(null);
			civilCreateWindow.getStudiesTxt().setText(null);
			civilCreateWindow.getPersonalPhoto().setIcon(null);
		}

	}

	public void checkYear(String year) {

		int yearCheck = Integer.parseInt(year);

		LocalDate todayDate = LocalDate.now();
		int actualYear = todayDate.getYear();
		if (yearCheck > actualYear) {

			JOptionPane.showMessageDialog(mw, "TU FECHA DE NACIMIENTO NO PUEDE SER MAYOR AL AÑO ACTUAL", "ERROR", 0);
			civilCreateWindow.getDocTxt().setText(null);
			civilCreateWindow.getDayBirthTxt().setText(null);
			civilCreateWindow.getMonthBirthTxt().setText(null);
			civilCreateWindow.getYearBirthTxt().setText(null);
			civilCreateWindow.getTimeArmyTxt().setText(null);
			civilCreateWindow.getNameTxt().setText(null);
			civilCreateWindow.getStudiesTxt().setText(null);
			civilCreateWindow.getPersonalPhoto().setIcon(null);
		}

	}

	public void checkIsEmpty(String document, String name, String dayOfBirth, String monthOfBirth, String yearOfBirth,
			String studiesLevel, String photoLocation, String timeWorkingInArmy) throws EmptyDataException {

		String message = "TODOS LOS ESPACIOS DEBEN ESTAR COMPELTOS";
		if (document.equals("") || name.equals("") || dayOfBirth.equals("") || dayOfBirth.equals("")
				|| monthOfBirth.equals("") || yearOfBirth.equals("") || studiesLevel.equals("")
				|| timeWorkingInArmy.equals("") || photoLocation.equals("")) {

			JOptionPane.showMessageDialog(mw, "TODOS LOS ESPACIOS DEBEN ESTAR COMPELTOS", "ERROR", 0);
			throw new EmptyDataException(message);
		} else {
		}
	}

	public String createCopyOfImage(String photoLocation) {
		File newFile = new File(photoLocation);
		String dest = "";
		if (newFile != null) {

			try {

				dest = "src/Images/" + newFile.getName();
				Path destiny = Paths.get(dest);
				String orig = newFile.getPath();
				Path origin = Paths.get(orig);
				Files.copy(origin, destiny);

			} catch (Exception e) {

			}
		}
		String photoLocation1 = "";
		photoLocation1 = dest;
		return photoLocation1;
	}

}
