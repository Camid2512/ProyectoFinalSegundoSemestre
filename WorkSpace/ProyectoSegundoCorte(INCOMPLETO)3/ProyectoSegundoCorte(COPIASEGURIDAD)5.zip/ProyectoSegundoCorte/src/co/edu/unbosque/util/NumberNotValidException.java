package co.edu.unbosque.util;

public class NumberNotValidException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7387645943625430992L;

	public NumberNotValidException() {

		super("El numero no tiene un formato valido");
		// TODO Auto-generated constructor stub
	}

	public NumberNotValidException(String message) {
		super(message);
	}

}
