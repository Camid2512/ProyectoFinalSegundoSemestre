package co.edu.unbosque.util;

public class NotValidFormatException extends Exception {

	private static final long serialVersionUID = -457852048289649104L;

	public NotValidFormatException() {

		super("El archivo elegido no es valido");

	}

	public NotValidFormatException(String mensaje) {

		super(mensaje);

	}

}
