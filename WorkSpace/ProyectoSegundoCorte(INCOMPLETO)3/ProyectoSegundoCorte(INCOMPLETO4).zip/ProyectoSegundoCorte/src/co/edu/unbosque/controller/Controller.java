package co.edu.unbosque.controller;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

import co.edu.unbosque.model.persistence.CivilDAO;
import co.edu.unbosque.model.persistence.PersonDAO;
import co.edu.unbosque.view.CivilCreateWindow;
import co.edu.unbosque.view.CivilWindowCRUD;
import co.edu.unbosque.view.MainMilitarWindow;
import co.edu.unbosque.view.MainWindow;
import co.edu.unbosque.view.MilitarForeignWindowCRUD;
import co.edu.unbosque.view.MilitarLocalWindowCRUD;

public class Controller implements ActionListener {

	private MainWindow mw;
	private CivilWindowCRUD civilWindow;
	private CivilCreateWindow civilCreateWindow;
	private MainMilitarWindow mainMilitarWindow;
	private MilitarLocalWindowCRUD militarLocalWindow;
	private MilitarForeignWindowCRUD militarForeignWindow;
	private JFileChooser fileChooser;
	private CivilDAO civilDAO;
	private PersonDAO personDAO;

	private String photoLocation1;

	public Controller() {

		civilDAO = new CivilDAO();
		personDAO = new PersonDAO();

		photoLocation1 = "";

		mw = new MainWindow();
		civilWindow = new CivilWindowCRUD();
		civilCreateWindow = new CivilCreateWindow();
		mainMilitarWindow = new MainMilitarWindow();
		militarLocalWindow = new MilitarLocalWindowCRUD();
		militarForeignWindow = new MilitarForeignWindowCRUD();
		fileChooser = new JFileChooser();
		agregarLectores();
	}

	public void run() {
		mw.setVisible(true);

	}

	public void agregarLectores() {

		// BOTONES VENTANA PRINCIPAL
		mw.getCivilBtn().addActionListener(this);
		mw.getCivilBtn().setActionCommand("botonCivilPaginaPrincipal");
		mw.getMilitarBtn().addActionListener(this);
		mw.getMilitarBtn().setActionCommand("botonMilitarPaginaPrincipal");
		mw.getVideoBtn().addActionListener(this);
		mw.getVideoBtn().setActionCommand("botonVideoTutorialPaginaPrincipal");
		mw.getSalir().addActionListener(this);
		mw.getSalir().setActionCommand("botonSalirVentanaPrincipal");

		// BOTONES VENTANA CIVIL
		civilWindow.getBackBtn().addActionListener(this);
		civilWindow.getBackBtn().setActionCommand("botonVolverCivil");
		civilWindow.getCreateBtn().addActionListener(this);
		civilWindow.getCreateBtn().setActionCommand("botonCrearCivil");
		// BOTONES VENTANA CIVIL CREAR
		civilCreateWindow.getBackBtn().addActionListener(this);
		civilCreateWindow.getBackBtn().setActionCommand("botonVolverCivilCrear");
		civilCreateWindow.getCreateBtn().addActionListener(this);
		civilCreateWindow.getCreateBtn().setActionCommand("BOTONCREARCIVIL");
		civilCreateWindow.getFileChooserBtn().addActionListener(this);
		civilCreateWindow.getFileChooserBtn().setActionCommand("escogerArchivoBotonCivil");

		// BOTONES VENTANA MILITAR
		mainMilitarWindow.getBackBtn().addActionListener(this);
		mainMilitarWindow.getBackBtn().setActionCommand("botonVolverMilitarMain");
		mainMilitarWindow.getMilitarLocal().addActionListener(this);
		mainMilitarWindow.getMilitarLocal().setActionCommand("botonMilitarLocal");
		mainMilitarWindow.getMilitarForeign().addActionListener(this);
		mainMilitarWindow.getMilitarForeign().setActionCommand("botonMilitarExtranjero");

		// BOTONES VENTANA MILITAR LOCAL
		militarLocalWindow.getBackBtn().addActionListener(this);
		militarLocalWindow.getBackBtn().setActionCommand("botonVolverMilitarLocal");
		militarLocalWindow.getCreateBtn().addActionListener(this);
		militarLocalWindow.getCreateBtn().setActionCommand("botonCrearMilitarLocal");

		// BOTONES VENTANA MILITAR EXTRANJERO
		militarForeignWindow.getBackBtn().addActionListener(this);
		militarForeignWindow.getBackBtn().setActionCommand("botonVolverMilitarExtranjero");

	}

	public void actionPerformed(ActionEvent e) {
		switch (e.getActionCommand()) {

		// CASOS BOTONES VENTANA PRINCIPAL
		case "botonCivilPaginaPrincipal": {
			mw.setVisible(false);
			civilWindow.setVisible(true);

			break;
		}

		case "botonMilitarPaginaPrincipal": {
			mw.setVisible(false);
			mainMilitarWindow.setVisible(true);

			break;
		}

		case "botonVideoTutorialPaginaPrincipal": {
			JOptionPane.showMessageDialog(mw, "Videooooo", "ERROR", 0);

			break;
		}

		case "botonSalirVentanaPrincipal": {
			System.exit(1);
			break;
		}

		// CASOS BOTONES CIVIL
		case "botonVolverCivil": {
			mw.setVisible(true);
			civilWindow.setVisible(false);

			break;
		}
		case "botonCrearCivil": {

			mw.setVisible(false);
			civilWindow.setVisible(false);
			civilCreateWindow.setVisible(true);
			break;
		}
		case "escogerArchivoBotonCivil": {

			FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & PNG", "jpeg", "JPEG", "jpg", "JPG",
					"png", "PNG");
			fileChooser.setFileFilter(filter);

			int response = fileChooser.showOpenDialog(null);
			if (response == JFileChooser.APPROVE_OPTION) {

				String photoLocation = fileChooser.getSelectedFile().getPath();
				createCopyOfImage(photoLocation);
				photoLocation1 = createCopyOfImage(photoLocation);

				Image myImage = new ImageIcon(photoLocation).getImage();
				ImageIcon myIcon = new ImageIcon(myImage.getScaledInstance(372, 385, Image.SCALE_DEFAULT));

				civilCreateWindow.getPersonalPhoto().setIcon(myIcon);
				;

			}

			break;
		}
		// CASOS BOTONES CREAR CIVIL

		case "botonVolverCivilCrear": {

			civilCreateWindow.setVisible(false);
			civilCreateWindow.getDocTxt().setText("");
			civilCreateWindow.getNameTxt().setText("");
			civilCreateWindow.getDayBirthTxt().setText("");
			civilCreateWindow.getMonthBirthTxt().setText("");
			civilCreateWindow.getYearBirthTxt().setText("");
			civilCreateWindow.getStudiesTxt().setText("");
			civilCreateWindow.getTimeArmyTxt().setText("");
			civilCreateWindow.getPersonalPhoto().setIcon(null);
			civilWindow.setVisible(true);

			break;
		}
		case "BOTONCREARCIVIL": {
			while (true) {

				createCivil();
				JOptionPane.showMessageDialog(civilCreateWindow, "Se ha creado con exito la persona civil");
				civilCreateWindow.getDocTxt().setText("");
				civilCreateWindow.getNameTxt().setText("");
				civilCreateWindow.getDayBirthTxt().setText("");
				civilCreateWindow.getMonthBirthTxt().setText("");
				civilCreateWindow.getYearBirthTxt().setText("");
				civilCreateWindow.getStudiesTxt().setText("");
				civilCreateWindow.getTimeArmyTxt().setText("");
				civilCreateWindow.getPersonalPhoto().setIcon(null);
				break;
			}
			break;
		}

		// CASOS BOTONES MILITAR
		case "botonVolverMilitarMain": {
			mw.setVisible(true);
			mainMilitarWindow.setVisible(false);

			break;
		}
		case "botonMilitarExtranjero": {
			mw.setVisible(false);
			mainMilitarWindow.setVisible(false);
			militarForeignWindow.setVisible(true);

			break;
		}
		case "botonMilitarLocal": {
			mw.setVisible(false);
			mainMilitarWindow.setVisible(false);
			militarLocalWindow.setVisible(true);

			break;
		}

		// CASOS BOTONES MILITAR LOCAL
		case "botonVolverMilitarLocal": {
			militarLocalWindow.setVisible(false);
			mainMilitarWindow.setVisible(true);

			break;
		}
		// CASOS BOTONES MILITAR EXTRANJERO
		case "botonVolverMilitarExtranjero": {
			militarForeignWindow.setVisible(false);
			mainMilitarWindow.setVisible(true);

			break;
		}

		default: {

			break;

		}
		}

	}

	public void createCivil() {

		String document = "";
		String name = "";
		String dayOfBirth = "";
		String monthOfBirth = "";
		String yearOfBirth = "";
		String photoLocation = "";
		String age = "";
		String studiesLevel = "";
		String timeWorkingInArmy = "";

		int day = 0;
		int month = 0;
		int year = 0;
		document = civilCreateWindow.getDocTxt().getText();
		checkNegativeNumber(document);
		checkIsNotANumber(document);
		name = civilCreateWindow.getNameTxt().getText();
		checkName(name);
		dayOfBirth = civilCreateWindow.getDayBirthTxt().getText();
		checkNegativeNumber(dayOfBirth);
		checkIsNotANumber(dayOfBirth);
		monthOfBirth = civilCreateWindow.getMonthBirthTxt().getText();
		checkNegativeNumber(monthOfBirth);
		checkIsNotANumber(monthOfBirth);
		yearOfBirth = civilCreateWindow.getYearBirthTxt().getText();
		checkNegativeNumber(yearOfBirth);
		checkIsNotANumber(yearOfBirth);

		studiesLevel = civilCreateWindow.getStudiesTxt().getText();
		checkName(studiesLevel);

		photoLocation = photoLocation1;

		timeWorkingInArmy = civilCreateWindow.getTimeArmyTxt().getText();
		checkNegativeNumber(timeWorkingInArmy);
		checkIsNotANumber(timeWorkingInArmy);
		day = Integer.parseInt(dayOfBirth);
		checkDay(day);
		month = Integer.parseInt(monthOfBirth);
		checkMonth(month);
		year = Integer.parseInt(yearOfBirth);
		checkYear(year);

		age = String.valueOf(personDAO.ageCalculation(day, month, year));
		civilDAO.create(document, name, dayOfBirth, monthOfBirth, yearOfBirth, age, photoLocation, studiesLevel,
				timeWorkingInArmy);

	}

	public void checkIsNotANumber(String num) {

		for (char c : num.toCharArray()) {
			if (Character.isAlphabetic(c) || Character.isWhitespace(c)) {
				JOptionPane.showMessageDialog(mw, "LOS NUMEROS SOLO PUEDEN SER NUMEROS", "ERROR", 0);
				civilCreateWindow.getDocTxt().setText(null);
				civilCreateWindow.getDayBirthTxt().setText(null);
				civilCreateWindow.getMonthBirthTxt().setText(null);
				civilCreateWindow.getYearBirthTxt().setText(null);
				civilCreateWindow.getTimeArmyTxt().setText(null);
			}
		}

	}

	public void checkNegativeNumber(String num) {

		if (Integer.parseInt(num) < 0) {

			JOptionPane.showMessageDialog(mw, "NINGUNO DE LOS NUMEROS PUEDE SER NEGATIVO", "ERROR", 0);
			civilCreateWindow.getDocTxt().setText(null);
			civilCreateWindow.getDayBirthTxt().setText(null);
			civilCreateWindow.getMonthBirthTxt().setText(null);
			civilCreateWindow.getYearBirthTxt().setText(null);
			civilCreateWindow.getTimeArmyTxt().setText(null);
			civilCreateWindow.getNameTxt().setText(null);
			civilCreateWindow.getStudiesTxt().setText(null);
		} else if (Long.parseLong(num) < 0) {

			JOptionPane.showMessageDialog(mw, "NINGUNO DE LOS NUMEROS PUEDE SER NEGATIVO", "ERROR", 0);
			civilCreateWindow.getDocTxt().setText(null);
			civilCreateWindow.getDayBirthTxt().setText(null);
			civilCreateWindow.getMonthBirthTxt().setText(null);
			civilCreateWindow.getYearBirthTxt().setText(null);
			civilCreateWindow.getTimeArmyTxt().setText(null);
			civilCreateWindow.getNameTxt().setText(null);
			civilCreateWindow.getStudiesTxt().setText(null);
		}

	}

	public void checkName(String name) {

		for (char c : name.toCharArray()) {
			if (!Character.isAlphabetic(c) && !Character.isWhitespace(c)) {
				JOptionPane.showMessageDialog(civilCreateWindow, "LOS NOMBRES NO CONTIENEN CARACTERES ESPECIALES",
						"ERROR", 0);
				civilCreateWindow.getDocTxt().setText(null);
				civilCreateWindow.getDayBirthTxt().setText(null);
				civilCreateWindow.getMonthBirthTxt().setText(null);
				civilCreateWindow.getYearBirthTxt().setText(null);
				civilCreateWindow.getTimeArmyTxt().setText(null);
				civilCreateWindow.getNameTxt().setText(null);
				civilCreateWindow.getStudiesTxt().setText(null);
			}
		}
	}

	public void checkDay(int day) {

		if (day > 30) {
			JOptionPane.showMessageDialog(mw, "LOS DIAS DEL MES NO PUEDEN SER MAYORES A 30", "ERROR", 0);
			civilCreateWindow.getDocTxt().setText(null);
			civilCreateWindow.getDayBirthTxt().setText(null);
			civilCreateWindow.getMonthBirthTxt().setText(null);
			civilCreateWindow.getYearBirthTxt().setText(null);
			civilCreateWindow.getTimeArmyTxt().setText(null);
			civilCreateWindow.getNameTxt().setText(null);
			civilCreateWindow.getStudiesTxt().setText(null);
		}

	}

	public void checkMonth(int month) {

		if (month > 12) {
			JOptionPane.showMessageDialog(mw, "NO HAY MAS DE 12 MESES EN EL AÑO", "ERROR", 0);
			civilCreateWindow.getDocTxt().setText(null);
			civilCreateWindow.getDayBirthTxt().setText(null);
			civilCreateWindow.getMonthBirthTxt().setText(null);
			civilCreateWindow.getYearBirthTxt().setText(null);
			civilCreateWindow.getTimeArmyTxt().setText(null);
			civilCreateWindow.getNameTxt().setText(null);
			civilCreateWindow.getStudiesTxt().setText(null);
		}

	}

	public void checkYear(int year) {

		LocalDate todayDate = LocalDate.now();
		int actualYear = todayDate.getYear();
		if (year > actualYear) {

			JOptionPane.showMessageDialog(mw, "TU FECHA DE NACIMIENTO NO PUEDE SER MAYOR AL AÑO ACTUAL", "ERROR", 0);
			civilCreateWindow.getDocTxt().setText(null);
			civilCreateWindow.getDayBirthTxt().setText(null);
			civilCreateWindow.getMonthBirthTxt().setText(null);
			civilCreateWindow.getYearBirthTxt().setText(null);
			civilCreateWindow.getTimeArmyTxt().setText(null);
			civilCreateWindow.getNameTxt().setText(null);
			civilCreateWindow.getStudiesTxt().setText(null);
		}

	}

	public String createCopyOfImage(String photoLocation) {
		File newFile = new File(photoLocation);
		String dest = "";
		if (newFile != null) {

			try {

				dest = "src/Images/" + newFile.getName();
				Path destiny = Paths.get(dest);
				String orig = newFile.getPath();
				Path origin = Paths.get(orig);
				Files.copy(origin, destiny);

			} catch (Exception e) {

			}
		}
		String photoLocation1 = "";
		photoLocation1 = dest;
		return photoLocation1;
	}

}
