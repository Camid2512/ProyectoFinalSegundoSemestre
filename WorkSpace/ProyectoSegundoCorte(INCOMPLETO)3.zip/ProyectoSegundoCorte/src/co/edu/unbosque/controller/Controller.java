package co.edu.unbosque.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import co.edu.unbosque.view.CivilWindowCRUD;
import co.edu.unbosque.view.MainMilitarWindow;
import co.edu.unbosque.view.MainWindow;
import co.edu.unbosque.view.MilitarForeignWindowCRUD;
import co.edu.unbosque.view.MilitarLocalWindowCRUD;

public class Controller implements ActionListener {

	private MainWindow mw;
	private CivilWindowCRUD  civilWindow;
	private MainMilitarWindow mainMilitarWindow;
	private MilitarLocalWindowCRUD militarLocalWindow;
	private MilitarForeignWindowCRUD militarForeignWindow;

	public Controller() {

		mw = new MainWindow();
		civilWindow = new CivilWindowCRUD();
		mainMilitarWindow = new MainMilitarWindow();
		militarLocalWindow = new MilitarLocalWindowCRUD();
		militarForeignWindow = new MilitarForeignWindowCRUD();
		agregarLectores();
	}

	public void run() {
		mw.setVisible(true);

	}

	public void agregarLectores() {
		mw.getCivilBtn().addActionListener(this);
		mw.getCivilBtn().setActionCommand("botonCivilPaginaPrincipal");

		mw.getMilitarBtn().addActionListener(this);
		mw.getMilitarBtn().setActionCommand("botonMilitarPaginaPrincipal");

		mw.getVideoBtn().addActionListener(this);
		mw.getVideoBtn().setActionCommand("botonVideoTutorialPaginaPrincipal");
		
		mw.getSalir().addActionListener(this);
		mw.getSalir().setActionCommand("botonSalirVentanaPrincipal");
		
		civilWindow.getBackBtn().addActionListener(this);
		civilWindow.getBackBtn().setActionCommand("botonVolverCivil");
		
		mainMilitarWindow.getBackBtn().addActionListener(this);
		mainMilitarWindow.getBackBtn().setActionCommand("botonVolverMilitarMain");
		mainMilitarWindow.getMilitarLocal().addActionListener(this);
		mainMilitarWindow.getMilitarLocal().setActionCommand("botonMilitarLocal");
		mainMilitarWindow.getMilitarForeign().addActionListener(this);
		mainMilitarWindow.getMilitarForeign().setActionCommand("botonMilitarExtranjero");

		militarLocalWindow.getBackBtn().addActionListener(this);
		militarLocalWindow.getBackBtn().setActionCommand("botonVolverMilitarLocal");
		
		militarForeignWindow.getBackBtn().addActionListener(this);
		militarForeignWindow.getBackBtn().setActionCommand("botonVolverMilitarExtranjero");
		
		
	}

	public void actionPerformed(ActionEvent e) {

		switch (e.getActionCommand()) {
		
		case "botonCivilPaginaPrincipal":{
			mw.setVisible(false);
			civilWindow.setVisible(true);
			

			break;
		}

		case "botonMilitarPaginaPrincipal":{
			mw.setVisible(false);
			mainMilitarWindow.setVisible(true);

			break;
		}
		case "botonMilitarLocal":{
			mw.setVisible(false);
			mainMilitarWindow.setVisible(false);
			militarLocalWindow.setVisible(true);
			
			
			break;
		}
		case "botonMilitarExtranjero":{
			mw.setVisible(false);
			mainMilitarWindow.setVisible(false);
			militarForeignWindow.setVisible(true);
			
			break;
		}
		
		case "botonVideoTutorialPaginaPrincipal":{
			JOptionPane.showMessageDialog(mw, "Videooooo");
			
			break;
		}
			
		case "botonSalirVentanaPrincipal": {
			System.exit(1);
			break;
		}
		
		case "botonVolverCivil": {
			mw.setVisible(true);
			civilWindow.setVisible(false);
			
			break;
		}
		case "botonVolverMilitarMain": {
			mw.setVisible(true);
			mainMilitarWindow.setVisible(false);
			
			break;
		}
		
		case "botonVolverMilitarLocal": {
			militarLocalWindow.setVisible(false);
			mainMilitarWindow.setVisible(true);
			
			
			break;
		}
		case "botonVolverMilitarExtranjero": {
			militarForeignWindow.setVisible(false);
			mainMilitarWindow.setVisible(true);
			
			
			break;
		}
		

		default:
			break;
		}

	}

}
