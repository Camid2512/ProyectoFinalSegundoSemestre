/**
 * Paquete con pruebas unitarias concisas
 * 
 * @author SOFTPYLSA
 * 
 * @version 1.0
 * @since 10/11/2023
 */
package co.edu.unbosque.test;