/**
 * Paquete con parametros de ejecucion y control del programa
 * 
 * @author SOFTPYLSA
 * 
 * @version 1.0
 * @since 10/11/2023
 */
package co.edu.unbosque.controller;
