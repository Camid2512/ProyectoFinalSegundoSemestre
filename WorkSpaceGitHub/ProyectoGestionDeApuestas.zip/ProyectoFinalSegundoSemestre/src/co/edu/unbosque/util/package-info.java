/**
 * Paquete del manejo de excepciones
 * 
 * @author SOFTPYLSA
 * 
 * @version 1.0
 * @since 10/11/2023
 */
package co.edu.unbosque.util;