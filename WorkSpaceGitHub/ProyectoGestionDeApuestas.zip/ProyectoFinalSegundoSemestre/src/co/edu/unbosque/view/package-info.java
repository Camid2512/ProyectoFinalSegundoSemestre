/**
 * Este paquete contiene todas las clases necesarias para parte visual del
 * aplicativo
 * 
 * @author SOFTPYLSA
 * @version 1.0
 * @since 10/11/2023
 */
package co.edu.unbosque.view;