/**
 * Este paquete contiene todas las clases necesarias para obtener la informacion de los DTO
 * 
 * @author SOFTPYLSA
 * @version 1.0
 * @since 10/11/2023
 */

package co.edu.unbosque.model.persistence;