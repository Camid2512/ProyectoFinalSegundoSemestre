/**
 * Este paquete contiene todas las clases necesarias de Objetos de transferencia
 * de datos
 * 
 * @author SOFTPYLSA
 * @version 1.0
 * @since 10/11/2023
 */
package co.edu.unbosque.model;